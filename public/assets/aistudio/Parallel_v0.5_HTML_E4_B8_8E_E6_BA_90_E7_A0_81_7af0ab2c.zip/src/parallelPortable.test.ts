import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

function createPortableEngine(options?: {
  store?: Map<string, string>;
  fetchImpl?: (url: string, init?: any) => Promise<any>;
}) {
  const src = fs.readFileSync(
    path.resolve(process.cwd(), 'public/parallel/offline.js'),
    'utf8'
  );
  const store = options?.store ?? new Map<string, string>();
  const localStorage = {
    getItem: (k: string) => store.get(k) ?? null,
    setItem: (k: string, v: string) => {
      store.set(k, v);
    },
  };
  const win: Record<string, unknown> = {};
  const context = {
    window: win,
    localStorage,
    crypto: webcrypto,
    URLSearchParams,
    Date,
    JSON,
    Math,
    TextEncoder,
    console,
    fetch:
      options?.fetchImpl ??
      (async () => {
        throw new Error('network disabled in unit tests');
      }),
  };
  vm.createContext(context);
  vm.runInContext(src, context);
  return {
    engine: win.ParallelOffline as {
      request: (p: string, b?: Record<string, unknown>) => Promise<any>;
      buildPromptPreview: (
        pid: string,
        cid: string,
        mode?: string,
        options?: Record<string, unknown>
      ) => Array<{ role: string; content: string }>;
      diagnosePresets: (mode?: string) => any;
      getSystemLogs: () => any[];
      clearSystemLogs: () => any[];
      exportData: () => string;
      importData: (raw: string) => { profiles: number; messages: number };
    },
    store,
  };
}

test('Parallel v0.5 four-layer memory isolation, on-demand retrieval, and conversational correction', async () => {
  const { engine } = createPortableEngine();
  const steph = (
    await engine.request('/profile', {
      name: 'Stephanie',
      age: 26,
      gender: 'female',
      interested_in: ['all'],
      min_age: 18,
      max_age: 65,
      intent: '认识新朋友',
      sources: ['生化危机 · 游戏'],
      bio: '喜欢悬疑电影与黑咖啡',
      interests: ['电影', '黑咖啡'],
    })
  ).profile;

  const alice = (
    await engine.request('/profile', {
      name: 'Alice',
      age: 24,
      gender: 'female',
      interested_in: ['all'],
      min_age: 18,
      max_age: 65,
      intent: '认真寻找恋人',
      sources: ['生化危机 · 游戏'],
      bio: '喜欢滑雪',
      interests: ['滑雪'],
    })
  ).profile;

  const cid = 're-game:leon:re2';
  for (let i = 0; i < 15; i++) {
    if ((await engine.request('/swipe', { profileId: steph.id, characterId: cid, direction: 'right' })).matched) break;
  }
  for (let i = 0; i < 15; i++) {
    if ((await engine.request('/swipe', { profileId: alice.id, characterId: cid, direction: 'right' })).matched) break;
  }

  await engine.request('/memory-action', {
    profileId: alice.id,
    characterId: cid,
    action: 'add',
    summary: '与 Alice 约定去阿尔卑斯山滑雪',
  });

  // 1. Strict isolation: Stephanie's prompt must never include Alice's name or memories
  const stephPrompt = JSON.stringify(engine.buildPromptPreview(steph.id, cid, 'chat'));
  assert.ok(!stephPrompt.includes('Alice'), 'Other profile name never leaks into prompt');
  assert.ok(!stephPrompt.includes('阿尔卑斯山'), 'Other profile memory never leaks into prompt');
  assert.ok(stephPrompt.includes('【第一层 · 身份记忆'), 'Layer 1 Identity Memory present');
  assert.ok(stephPrompt.includes('【第二层 · 关系记忆基线'), 'Layer 2 Relationship Baseline present');
  assert.ok(stephPrompt.includes('【第三层 · 按需检索命中的过往记忆'), 'Layer 3 Retrieved Episodic Memory header present');
  assert.ok(stephPrompt.includes('【第四层 · 当前状态'), 'Layer 4 Current State header present');

  // 2. On-demand retrieval recalls relevant memories under (cid, steph.id)
  await engine.request('/memory-action', {
    profileId: steph.id,
    characterId: cid,
    action: 'add',
    summary: 'Stephanie 提到周六想去老城区唱片行买爵士黑胶',
  });
  const memSearch = await engine.request(
    `/memories?profileId=${steph.id}&characterId=${encodeURIComponent(cid)}&query=${encodeURIComponent('老城区爵士黑胶')}`
  );
  assert.ok(
    memSearch.recalledPreview.some((m: any) => m.summary.includes('爵士黑胶')),
    'Keyword & bigram search retrieves relevant episodic memory'
  );

  // 3. Conversational correction marks old memory disputed and inserts a clarification record
  await engine.request('/message', {
    profileId: steph.id,
    characterId: cid,
    text: '你记错了，我们没有去老城区唱片行买爵士黑胶',
  });
  const afterCorr = await engine.request(
    `/memories?profileId=${steph.id}&characterId=${encodeURIComponent(cid)}&query=${encodeURIComponent('唱片行')}`
  );
  const orig = afterCorr.memories.find(
    (m: any) => m.source_type !== 'correction' && m.summary.includes('老城区唱片行买爵士黑胶')
  );
  assert.equal(orig?.disputed, 1, 'Original memory marked disputed after conversational correction');
  assert.ok(
    afterCorr.memories.some((m: any) => m.source_type === 'correction' && m.clarifies_id === orig?.id),
    'Correction memory entry added and linked via clarifies_id'
  );
});

test('Parallel v0.5 source tag aliases and installment filtering (巫师3, 生化2)', async () => {
  const { engine } = createPortableEngine();
  const witcher = (
    await engine.request('/profile', {
      name: 'WitcherPlayer',
      age: 24,
      gender: 'female',
      interested_in: ['all'],
      min_age: 18,
      max_age: 99,
      sources: ['巫师3'],
      intent: '认真寻找恋人',
      interests: ['昆特牌', '剑术'],
      bio: '寻找同路人',
    })
  ).profile;

  const wDiscover = await engine.request('/discover', { profileId: witcher.id });
  assert.ok(wDiscover.candidates.length > 0, '巫师3 should match Witcher 3 characters');
  assert.ok(
    wDiscover.candidates.every((c: any) => c.source === '巫师 · 游戏'),
    'All candidates for 巫师3 belong to 巫师 · 游戏'
  );

  const re2 = (
    await engine.request('/profile', {
      name: 'RaccoonFan',
      age: 22,
      gender: 'female',
      interested_in: ['all'],
      min_age: 18,
      max_age: 99,
      sources: ['生化2'],
      intent: '认识新朋友',
      interests: ['摩托车'],
      bio: '浣熊市新人',
    })
  ).profile;

  const r2Discover = await engine.request('/discover', { profileId: re2.id });
  assert.ok(
    r2Discover.candidates.some((c: any) => c.id === 're-game:leon:re2'),
    '生化2 includes RE2 Leon'
  );
  assert.ok(
    !r2Discover.candidates.some((c: any) => c.id === 're-game:leon:re4'),
    '生化2 does not false-match RE4 Leon (2004)'
  );
});

test('Parallel v0.5 Chinese character full-name identify (艾达王, 冬日战士)', async () => {
  const { engine } = createPortableEngine();
  const ada = await engine.request('/identify?name=' + encodeURIComponent('艾达王'));
  assert.ok(ada.matches.some((m: any) => m.name === 'Ada Wong'));

  const bucky = await engine.request('/identify?name=' + encodeURIComponent('冬日战士'));
  assert.ok(bucky.matches.some((m: any) => m.name === 'Bucky Barnes'));
});

test('Parallel v0.5 matched candidate exclusion, message deletion, and legacy backup restore', async () => {
  const { engine } = createPortableEngine();
  const p = (
    await engine.request('/profile', {
      name: 'Stephanie',
      age: 26,
      gender: 'female',
      interested_in: ['all'],
      min_age: 18,
      max_age: 65,
      intent: '认识新朋友',
      sources: ['生化危机 · 游戏'],
      bio: '喜欢咖啡',
      interests: ['咖啡'],
    })
  ).profile;

  const cid = 're-game:leon:re2';
  let matched = false;
  for (let i = 0; i < 15; i++) {
    const res = await engine.request('/swipe', {
      profileId: p.id,
      characterId: cid,
      direction: 'right',
    });
    if (res.matched) {
      matched = true;
      break;
    }
  }
  assert.equal(matched, true);

  // Already matched character is excluded from discover pool
  const afterMatchPool = (await engine.request('/discover', { profileId: p.id })).candidates;
  assert.ok(!afterMatchPool.some((c: any) => c.id === cid));

  // Duplicate right swipe returns already_matched: true
  const dupSwipe = await engine.request('/swipe', {
    profileId: p.id,
    characterId: cid,
    direction: 'right',
  });
  assert.equal(dupSwipe.already_matched, true);

  // Queue message and delete it
  const sent = await engine.request('/message', {
    profileId: p.id,
    characterId: cid,
    text: '不小心发错的消息',
  });
  assert.equal(sent.queue.count, 1);

  const thread = await engine.request(`/thread?profileId=${p.id}&characterId=${cid}`);
  const lastMsg = thread.messages[thread.messages.length - 1];
  const delRes = await engine.request('/message-delete', {
    profileId: p.id,
    characterId: cid,
    messageId: lastMsg.id,
  });
  assert.equal(delRes.ok, true);
  assert.equal(delRes.queue.count, 0);

  // Legacy backup restore without photoDescriptions or bios
  const rawBackup = JSON.parse(engine.exportData());
  delete rawBackup.data.photoDescriptions;
  delete rawBackup.data.bios;
  delete rawBackup.data.queue;
  engine.importData(JSON.stringify(rawBackup));

  const photo = await engine.request('/photo-description', { characterId: cid });
  assert.ok(photo.description.includes('Leon'));
});

test('Parallel v0.5 Image AI connection settings and text/live mode toggle', async () => {
  const { engine } = createPortableEngine();
  const initial = await engine.request('/settings');
  assert.equal(initial.image_mode, 'text');
  assert.equal(initial.has_image_key, false);

  const updated = (
    await engine.request('/settings', {
      image_base_url: 'https://api.example.com/v1',
      image_api_key: 'sk-img-test-123',
      image_model: 'dall-e-3',
    })
  ).settings;
  assert.equal(updated.has_image_key, true);
  assert.equal(updated.image_mode, 'live');
  assert.equal('image_api_key' in updated, false);

  const exported = JSON.parse(engine.exportData());
  assert.equal(exported.data.connection.image_api_key, '');

  const cleared = (
    await engine.request('/settings', {
      clear_image_key: true,
    })
  ).settings;
  assert.equal(cleared.has_image_key, false);
  assert.equal(cleared.image_mode, 'text');
});

test('Parallel v0.5 API detection, normal mode vs demo mode, message recall prompt notice, and multi-bubble replies', async () => {
  const { engine } = createPortableEngine();
  const initial = await engine.request('/settings');
  assert.equal(initial.has_api_config, false, 'Fresh store has no API config filled');

  // Switch to normal mode (demo_enabled: false) when no API is configured
  const normalCfg = (await engine.request('/settings', { demo_enabled: false })).settings;
  assert.equal(normalCfg.demo_enabled, false);
  assert.equal(normalCfg.mode, 'normal');

  const p = (
    await engine.request('/profile', {
      name: 'NaiEn',
      age: 23,
      gender: 'female',
      interested_in: ['all'],
      min_age: 18,
      max_age: 65,
      intent: '认真寻找恋人',
      sources: ['生化危机 · 游戏'],
      bio: '测试撤回与多气泡',
      interests: ['音乐'],
    })
  ).profile;
  const cid = 're-game:leon:re2';
  for (let i = 0; i < 15; i++) {
    if ((await engine.request('/swipe', { profileId: p.id, characterId: cid, direction: 'right' })).matched) break;
  }

  // In normal mode without API config, flushing chat returns warning and null reply instead of generating demo replies
  const sent = await engine.request('/message', {
    profileId: p.id,
    characterId: cid,
    text: '这条秘密消息一会儿要撤回12345',
  });
  assert.equal(sent.queue.count, 1);
  assert.equal(sent.queue.pendingIds.length, 1);

  const blockedFlush = await engine.request('/chat-flush', {
    profileId: p.id,
    characterId: cid,
    force: true,
  });
  assert.equal(blockedFlush.reply, null, 'Normal mode without API does not generate demo reply');
  assert.ok(blockedFlush.warning.includes('尚未连接 API'), 'Normal mode without API returns clear warning');

  // Recall the user message: AI sees recall notice in prompt, NOT the secret content
  const threadBefore = await engine.request(`/thread?profileId=${p.id}&characterId=${cid}`);
  const targetMsg = threadBefore.messages[threadBefore.messages.length - 1];
  const recallRes = await engine.request('/message-delete', {
    profileId: p.id,
    characterId: cid,
    messageId: targetMsg.id,
  });
  assert.equal(recallRes.ok, true);
  assert.equal(recallRes.recalled, true);
  assert.equal(recallRes.queue.count, 0);

  const promptAfterRecall = JSON.stringify(engine.buildPromptPreview(p.id, cid, 'chat'));
  assert.ok(
    !promptAfterRecall.includes('这条秘密消息一会儿要撤回12345'),
    'Recalled message content must never leak to AI prompt'
  );
  assert.ok(
    promptAfterRecall.includes('对方刚刚撤回了一条消息'),
    'AI prompt includes notice that user recalled a message'
  );

  // Enable demo mode and verify multi-bubble replies array is returned
  await engine.request('/settings', { demo_enabled: true });
  await engine.request('/message', {
    profileId: p.id,
    characterId: cid,
    text: '你在干嘛呀？',
  });
  const flushed = await engine.request('/chat-flush', {
    profileId: p.id,
    characterId: cid,
    force: true,
  });
  assert.ok(Array.isArray(flushed.replies) && flushed.replies.length >= 1, 'Returns replies array for multi-bubble display');
  assert.ok(flushed.reply && flushed.reply.text, 'Returns last reply item for backwards compatibility');

  // Proactive check (/proactive-check) with an unresolved promise memory
  await engine.request('/memory-action', {
    profileId: p.id,
    characterId: cid,
    action: 'add',
    summary: '约定明天一起去靶场练习射击',
  });
  const proactiveRes = await engine.request('/proactive-check', {
    profileId: p.id,
    trigger: 'manual',
    characterId: cid,
  });
  assert.ok(
    Array.isArray(proactiveRes.delivered) && proactiveRes.delivered.length === 1,
    'Proactive check delivers proactive message for matched character'
  );
  assert.equal(proactiveRes.delivered[0].characterId, cid);
  assert.ok(proactiveRes.delivered[0].replies.length >= 1);
});

test('Parallel v0.5 dedicated meeting novel flow, meeting summary card, and clean grouped memory archive', async () => {
  const { engine } = createPortableEngine();
  const p = (
    await engine.request('/profile', {
      name: '奈恩',
      age: 22,
      gender: 'female',
      interested_in: ['all'],
      min_age: 18,
      max_age: 65,
      intent: '认真寻找恋人',
      sources: ['生化危机 · 游戏'],
      bio: '测试见面小说模式与见面卡片归档',
      interests: ['散步'],
    })
  ).profile;
  const cid = 're-game:chris:re5';
  for (let i = 0; i < 15; i++) {
    if ((await engine.request('/swipe', { profileId: p.id, characterId: cid, direction: 'right' })).matched) break;
  }

  // 1. User sends casual chat message (no promise keyword) -> should NOT spam episodicMemories with per-sentence dialogue
  await engine.request('/message', {
    profileId: p.id,
    characterId: cid,
    text: '我已经到街角咖啡馆门口了，等等，我好像看见你了。',
  });
  await engine.request('/chat-flush', {
    profileId: p.id,
    characterId: cid,
    force: true,
  });

  // 2. User clicks Meet button -> /mode with triggerOpening: true
  const enterMeeting = await engine.request('/mode', {
    profileId: p.id,
    characterId: cid,
    mode: 'meeting',
    triggerOpening: true,
  });
  assert.equal(enterMeeting.mode, 'meeting');
  assert.ok(enterMeeting.active_meeting_id, 'Assigns active_meeting_id');
  assert.ok(enterMeeting.meeting_location.includes('街角咖啡馆'), 'Infers meeting location from recent chat message');
  assert.ok(enterMeeting.openingReply && enterMeeting.openingReply.mode === 'meeting', 'Generates opening novel scene on entering meeting mode');

  // 3. User sends a turn inside the dedicated meeting novel page
  const novelReply = await engine.request('/message', {
    profileId: p.id,
    characterId: cid,
    text: '我朝他挥了挥手，笑着走过去坐下，把菜单递给他。',
    meetingLocation: enterMeeting.meeting_location,
  });
  assert.ok(novelReply.reply && novelReply.reply.mode === 'meeting');

  // 4. User clicks End Meeting -> /mode with finalizeMeeting: true
  const endMeeting = await engine.request('/mode', {
    profileId: p.id,
    characterId: cid,
    mode: 'chat',
    finalizeMeeting: true,
    meetingLocation: enterMeeting.meeting_location,
  });
  assert.equal(endMeeting.mode, 'chat');
  assert.ok(endMeeting.meetingRecord, 'Returns finalized meetingRecord for chat timeline card');
  assert.ok(endMeeting.meetingRecord.location.includes('街角咖啡馆'), 'Meeting card records location');
  assert.ok(endMeeting.meetingRecord.summary.length > 0, 'Meeting card records summary');
  assert.ok(Array.isArray(endMeeting.meetingRecord.entries) && endMeeting.meetingRecord.entries.length >= 3, 'Meeting card holds full novel transcript entries');

  // 5. Verify memory archive: no '开始面对面见面' or '返回手机聊天' milestone spam, and includes consolidated meeting_summary card + daily_summary with day_messages
  const memData = await engine.request(`/memories?profileId=${p.id}&characterId=${encodeURIComponent(cid)}`);
  const milestones = memData.episodic.filter((m: any) =>
    String(m.summary).includes('开始面对面见面') || String(m.summary).includes('返回手机聊天')
  );
  assert.equal(milestones.length, 0, 'Must never pollute memory archive with mode-switch milestone entries');

  const meetingMems = memData.episodic.filter((m: any) => m.memory_type === 'meeting_summary');
  assert.equal(meetingMems.length, 1, 'Creates exactly one consolidated meeting summary memory card');
  assert.ok(meetingMems[0].summary.includes('和 奈恩 在「'), 'Meeting memory card uses "和 奈恩 在「xx」见面" format');
  assert.equal(meetingMems[0].meeting_id, endMeeting.meetingRecord.id);

  const dailyMems = memData.episodic.filter((m: any) => m.memory_type === 'daily_summary');
  assert.ok(dailyMems.length >= 1, 'Groups daily chat into 1 daily summary card per day');
  assert.ok(Array.isArray(dailyMems[0].day_messages) && dailyMems[0].day_messages.length >= 1, 'Daily summary includes day_messages for modal inspection');
});

test('Parallel v0.5 Daily Mode message bundling (preserving scheduled dueAt & timestamps), Hot Chat Mode toggle, and staggered proactive messages', async () => {
  const { engine } = createPortableEngine();
  const p = (
    await engine.request('/profile', {
      name: '奈恩',
      age: 30,
      gender: 'female',
      interested_in: ['all'],
      min_age: 18,
      max_age: 65,
      intent: '认真寻找恋人',
      sources: ['生化危机 · 游戏'],
      bio: '测试热聊模式与日常打包模式',
      interests: ['电影'],
    })
  ).profile;
  const cid = 're-game:leon:re2';
  for (let i = 0; i < 15; i++) {
    if ((await engine.request('/swipe', { profileId: p.id, characterId: cid, direction: 'right' })).matched) break;
  }

  // 1. Default is Daily Mode (hotChat: false)
  const msg1 = await engine.request('/message', {
    profileId: p.id,
    characterId: cid,
    text: '今天下午天气真好，你在忙什么？',
  });
  assert.equal(msg1.queue.paceMode, 'daily');
  assert.equal(msg1.queue.hotChat, false);
  assert.equal(msg1.queue.count, 1);
  const firstDueAt = msg1.queue.dueAt;
  assert.ok(firstDueAt > Date.now() + 5 * 60 * 1000, 'Daily Mode schedules reply several minutes in the future');

  // 2. Sending a second message in Daily Mode bundles into the same batch WITHOUT postponing dueAt
  const msg2 = await engine.request('/message', {
    profileId: p.id,
    characterId: cid,
    text: '对了，我刚买了一杯冰拿铁。',
  });
  assert.equal(msg2.queue.count, 2);
  assert.equal(msg2.queue.dueAt, firstDueAt, 'Subsequent messages in Daily Mode bundle without resetting dueAt');

  // 3. Prompt preview puts real time & mode into independent system metadata, does NOT prefix user/assistant turns with protocol headers, and preserves legitimate user-quoted protocol-style text
  const msgQuoted = await engine.request('/message', {
    profileId: p.id,
    characterId: cid,
    text: '他说：“请打开[短信 18:37]那条记录。”',
  });
  assert.equal(msgQuoted.queue.count, 3);
  const promptMessages = engine.buildPromptPreview(p.id, cid, 'chat') as Array<{
    role: string;
    content: string;
  }>;
  const sysPrompt = promptMessages[0]?.content || '';
  assert.match(
    sysPrompt,
    /【近期活跃对话时间与模式索引（系统元数据，仅供把握时间跨度与场景，严禁在回复正文中输出时间或模式前缀）】/,
    'System metadata section carries per-message time and mode index'
  );
  assert.match(
    sysPrompt,
    /#1 \d{2}:\d{2}（线上短信·Leon S\. Kennedy）/,
    'Each message in working history has its real timestamp and mode recorded in system metadata'
  );
  const nonSystemTurns = promptMessages.filter(
    (m) => m.role === 'user' || m.role === 'assistant'
  );
  assert.ok(nonSystemTurns.length >= 3);
  for (const turn of nonSystemTurns) {
    assert.ok(
      !/^\s*(?:\[|【)\s*(?:短信|见面)/.test(turn.content),
      `Normal user/assistant turn must not be prefixed with protocol header: ${turn.content}`
    );
  }
  assert.ok(
    nonSystemTurns.some(
      (t) => t.role === 'user' && t.content === '他说：“请打开[短信 18:37]那条记录。”'
    ),
    'Legitimate user-quoted protocol-style text must not be deleted during prompt serialization'
  );

  // 4. Toggle Hot Chat Mode on -> updates queue to paceMode: 'hot' with 60s dueAt
  const hotOn = await engine.request('/hot-chat', {
    profileId: p.id,
    characterId: cid,
    hotChat: true,
  });
  assert.equal(hotOn.hotChat, true);
  assert.equal(hotOn.queue.paceMode, 'hot');
  assert.ok(hotOn.queue.dueAt <= Date.now() + 61000, 'Hot Chat Mode sets 60s quiet window');

  const flushed = await engine.request('/chat-flush', {
    profileId: p.id,
    characterId: cid,
    force: true,
  });
  assert.ok(flushed.reply && flushed.replies.length >= 1, 'Flushes bundled messages and replies');
});

test('9. Surveillance (实时监控) silently generates full-day schedule, unlocks slots up to current time, syncs into prompt & meeting location, and rewrites timeline after meeting', async () => {
  const { engine } = createPortableEngine();
  const p = (
    await engine.request('/profile', {
      name: '奈恩',
      age: 22,
      gender: 'female',
      interested_in: ['all'],
      min_age: 18,
      max_age: 65,
      intent: '认真寻找恋人',
      sources: ['生化危机 · 游戏'],
      bio: '测试实时监控与见面同步',
      interests: ['电影'],
    })
  ).profile;
  const cid = 're-game:leon:re2';
  for (let i = 0; i < 15; i++) {
    if ((await engine.request('/swipe', { profileId: p.id, characterId: cid, direction: 'right' })).matched) break;
  }

  // 1. Thread response already includes silent surveillance payload with current slot & unlocked slots
  const thread = await engine.request(`/thread?profileId=${p.id}&characterId=${encodeURIComponent(cid)}`);
  assert.ok(thread.surveillance, 'Thread includes initial surveillance payload');
  assert.ok(thread.surveillance.current && thread.surveillance.current.location, 'Has active current surveillance slot');
  assert.ok(Array.isArray(thread.surveillance.unlockedSlots) && thread.surveillance.unlockedSlots.length >= 1, 'Unlocked slots up to current time exist');

  const initialLocation = thread.surveillance.current.location;

  // 2. Prompt preview includes live surveillance location & status synchronization
  const promptPreview = JSON.stringify(engine.buildPromptPreview(p.id, cid, 'chat'));
  assert.match(promptPreview, /【此刻你的真实位置与状态（实时监控同步）】/, 'Prompt includes live surveillance sync block');
  assert.ok(promptPreview.includes(initialLocation), 'Prompt includes current surveillance slot location');

  // 3. Entering meeting mode without an explicit location in chat defaults to current surveillance location
  const enterMeeting = await engine.request('/mode', {
    profileId: p.id,
    characterId: cid,
    mode: 'meeting',
    triggerOpening: true,
  });
  assert.equal(enterMeeting.mode, 'meeting');
  assert.equal(enterMeeting.meeting_location, initialLocation, 'Meeting location defaults to current surveillance slot location');
  assert.ok(
    enterMeeting.surveillance.current.status.includes('见面中'),
    'Live surveillance status immediately reflects active meeting with user'
  );

  // 4. Ending meeting mode rewrites today's surveillance footprint and shifts the next slot
  const endMeeting = await engine.request('/mode', {
    profileId: p.id,
    characterId: cid,
    mode: 'chat',
    finalizeMeeting: true,
  });
  assert.equal(endMeeting.mode, 'chat');
  assert.ok(endMeeting.meetingRecord, 'Meeting card archived');
  const slotsAfter = endMeeting.surveillance.unlockedSlots;
  assert.ok(
    slotsAfter.some((s: any) => s.source === 'meeting' && s.location === initialLocation),
    'Completed meeting is written into today surveillance footprint'
  );
});

test('10. Character Diary (角色日记) auto-generates past-day diaries from surveillance, supports date selection & intimacy stages, Surveillance supports past dates, and Character Hub supports custom nickname remarks', async () => {
  const { engine } = createPortableEngine();
  const p = (
    await engine.request('/profile', {
      name: '奈恩',
      age: 22,
      gender: 'female',
      interested_in: ['all'],
      min_age: 18,
      max_age: 65,
      intent: '认真寻找恋人',
      sources: ['生化危机 · 游戏'],
      bio: '测试角色日记、监控历史日期与专属空间备注修改',
      interests: ['电影'],
    })
  ).profile;
  const cid = 're-game:leon:re2';
  for (let i = 0; i < 15; i++) {
    if ((await engine.request('/swipe', { profileId: p.id, characterId: cid, direction: 'right' })).matched) break;
  }

  // 1. Surveillance supports selecting past dates (yesterday & two days ago) with full-day unlocked slots
  const survToday = await engine.request(`/surveillance?profileId=${p.id}&characterId=${encodeURIComponent(cid)}`);
  assert.equal(survToday.isToday, true, 'Default surveillance view is today');
  assert.ok(Array.isArray(survToday.availableDates) && survToday.availableDates.length >= 3, 'Seeds today + past dates in availableDates');

  const yesterdayDate = survToday.availableDates[1];
  const survYesterday = await engine.request(
    `/surveillance?profileId=${p.id}&characterId=${encodeURIComponent(cid)}&date=${encodeURIComponent(yesterdayDate)}`
  );
  assert.equal(survYesterday.date, yesterdayDate);
  assert.equal(survYesterday.isToday, false, 'Past date surveillance has isToday: false');
  assert.equal(survYesterday.lockedCount, 0, 'Past date surveillance unlocks all full-day slots');
  assert.equal(survYesterday.unlockedSlots.length, survYesterday.totalSlots, 'All slots unlocked on past date');

  // 2. Diary endpoint automatically generates past-day diaries from surveillance (without revolving around user in initial intimacy stage)
  const diaryLatest = await engine.request(`/diary?profileId=${p.id}&characterId=${encodeURIComponent(cid)}`);
  assert.ok(diaryLatest.diary, 'Returns latest diary entry');
  assert.equal(diaryLatest.date, yesterdayDate, 'Latest completed diary defaults to yesterday');
  assert.ok(Array.isArray(diaryLatest.availableDates) && diaryLatest.availableDates.length >= 2, 'Provides selectable past diary dates');
  assert.notEqual(diaryLatest.intimacy.stage, 'deep_love', 'Initial stage is independent life focus');
  assert.ok(
    Array.isArray(diaryLatest.diary.sourceLocations) && diaryLatest.diary.sourceLocations.length >= 2,
    'Diary is grounded in previous day surveillance locations'
  );
  assert.ok(diaryLatest.diary.content.length >= 40, 'Diary contains multi-paragraph prose');

  // Selecting an earlier diary date or any calendar past date (e.g., 2026-11-01) returns that specific day's surveillance & diary
  const twoDaysAgoDate = diaryLatest.availableDates[1];
  const diaryOlder = await engine.request(
    `/diary?profileId=${p.id}&characterId=${encodeURIComponent(cid)}&date=${encodeURIComponent(twoDaysAgoDate)}`
  );
  assert.equal(diaryOlder.date, twoDaysAgoDate, 'Can switch to an earlier date diary');
  assert.equal(diaryOlder.diary.date, twoDaysAgoDate);

  const arbitraryCalendarDate = '2026-11-01';
  const survCalendarPick = await engine.request(
    `/surveillance?profileId=${p.id}&characterId=${encodeURIComponent(cid)}&date=${arbitraryCalendarDate}`
  );
  assert.equal(survCalendarPick.date, arbitraryCalendarDate, 'Calendar input can pick any past date for surveillance');
  assert.equal(survCalendarPick.isToday, false);
  assert.equal(survCalendarPick.unlockedSlots.length, survCalendarPick.totalSlots);

  const diaryCalendarPick = await engine.request(
    `/diary?profileId=${p.id}&characterId=${encodeURIComponent(cid)}&date=${arbitraryCalendarDate}`
  );
  assert.equal(diaryCalendarPick.diary.date, arbitraryCalendarDate, 'Calendar input can pick any past date for diary');

  // 3. When intimacy reaches deep_love (affectionBoost >= 75), refreshing diary reflects deep affection for user
  await engine.request('/memory-action', {
    profileId: p.id,
    characterId: cid,
    action: 'affinity',
    delta: 80,
  });
  const deepLoveDiary = await engine.request('/diary', {
    profileId: p.id,
    characterId: cid,
    date: yesterdayDate,
    forceRefresh: true,
  });
  assert.equal(deepLoveDiary.intimacy.stage, 'deep_love');
  assert.equal(deepLoveDiary.diary.intimacyStage, 'deep_love');
  assert.ok(
    deepLoveDiary.diary.content.includes('奈恩'),
    'In deep_love stage, character diary openly pours out thoughts about user'
  );

  // 4. Custom nickname remark in Character Hub preserves true canon name while updating display_name
  const nickRes = await engine.request('/nickname', {
    profileId: p.id,
    characterId: cid,
    nickname: '里昂小队长',
  });
  assert.equal(nickRes.ok, true);
  assert.equal(nickRes.nickname, '里昂小队长');
  assert.equal(nickRes.character.display_name, '里昂小队长', 'display_name reflects custom remark');
  assert.equal(nickRes.character.name, 'Leon S. Kennedy', 'character.name preserves true canon name');

  // Clearing nickname reverts display_name back to canon name
  const clearNick = await engine.request('/nickname', {
    profileId: p.id,
    characterId: cid,
    nickname: '',
  });
  assert.equal(clearNick.nickname, '');
  assert.equal(clearNick.character.display_name, 'Leon S. Kennedy');
});

function load26EntryPresetFixture() {
  const localPath = path.resolve(process.cwd(), 'public/assets/aistudio/_____685745cf.json');
  if (fs.existsSync(localPath)) {
    return JSON.parse(fs.readFileSync(localPath, 'utf8'));
  }
  const entries = [];
  for (let i = 0; i < 26; i++) {
    const isDisabledStyle = i === 16 || i === 17;
    const isEnabledStyle = i === 18;
    const isCot = i === 24;
    const isBottom = i === 25;
    entries.push({
      id: `entry-${i + 1}`,
      name: isDisabledStyle
        ? i === 16
          ? '毛姆式冷眼世故'
          : '白水烹鲜温润白描'
        : isEnabledStyle
          ? '高饱和度感官电影流'
          : isCot
            ? '动笔前连续性检查'
            : isBottom
              ? '底部誓约与状态确认'
              : `专项模块-${i + 1}`,
      role: isBottom ? 'assistant' : 'system',
      enabled: !isDisabledStyle,
      group:
        isDisabledStyle || isEnabledStyle
          ? '文风（单选）'
          : isCot
            ? 'COT'
            : isBottom
              ? '收尾'
              : '专项（多选）',
      content: isBottom
        ? '【已完整读取并锁定所有前置档案与创作法则】\n我已完全进入 **{{char}}** 的灵魂与躯壳，并将 **{{user}}** 视为真实可触的唯一交互对手。'
        : isCot
          ? '动笔前快速过一遍：1. 先接住{{user}}刚落下的动作或话头；2. 检查{{char}}当前的认知边界。'
          : `规则条目 #${i + 1}：要求围绕 {{char}} 与 {{user}} 展开 600～1000 字细腻现实互动。`,
    });
  }
  return {
    id: 'preset-elsewhere-26',
    name: '26条目测试预设',
    description: '24启用、2禁用测试预设',
    schemaVersion: 1,
    format: 'elsewhere-preset',
    entries,
  };
}

test('ROUND-02: Complete 26-entry Elsewhere preset lifecycle, compilation order, 6 meeting entry points, diagnostics, long novel preservation, and System Logs', async () => {
  const capturedCalls: Array<{ url: string; body: any; headers: Record<string, string> }> = [];
  let mockResponseMode: 'long_novel' | 'truncated_length' | 'http_error' | 'chat_bubbles' = 'long_novel';

  const longNovelParagraphs = [
    '雨水顺着街角咖啡馆的玻璃窗蜿蜒滑落，将室外的霓虹灯影揉碎成一片温暖而模糊的琥珀色光斑。店内的烘焙香气混合着潮湿的夜气，在两人之间静静流淌。他没有急着开口，只是先把搭在椅背上的深色风衣往里收了收，免得沾湿的水汽碰到她手边的桌面，随后才抬起眼，目光沉静而专注地落在她身上。',
    '刚才她递过来的那页菜单还停留在指尖，纸页边缘带着一点室内的微温。他垂眸扫过上面用铅笔勾选的那行热可可，唇角极其自然地浮起一点克制而温和的弧度，既没有刻意凑近的轻佻，也没有刚见面时的生疏客套，完全是久经生死与风浪后难得卸下防备的松弛感。',
    '“外面的雨比气象台报的还要大一点，你过来的时候袖口是不是淋湿了？”他一边说着，一边用指节轻轻敲了敲桌面右侧的空位，顺手把侍应生刚放下的温水往她手边推近了半寸，掌心在玻璃杯壁外侧短暂停留了一秒确认温度，才自然地收回手搭在自己膝上。',
    '“既然今天好不容易把备勤的空档腾出来，我们就不用赶时间。你刚才在路上说的那家老唱片店，等这阵雨稍微小一点，我陪你过去看看还开没开门。现在先喝口热水暖一暖——你想先点单，还是先跟我说说今天下午到底遇到了什么好玩的事？”',
  ].join('\n\n');
  assert.ok(longNovelParagraphs.length >= 420, 'Mock novel response has substantial multi-paragraph length');

  const sharedStore = new Map<string, string>();
  const makeFetch = () => async (url: string, init?: any) => {
    const reqBody = init?.body ? JSON.parse(String(init.body)) : {};
    const reqHeaders = init?.headers || {};
    capturedCalls.push({ url: String(url), body: reqBody, headers: reqHeaders });
    if (mockResponseMode === 'http_error') {
      return {
        ok: false,
        status: 502,
        json: async () => ({ error: { message: 'Upstream gateway timeout' } }),
      };
    }
    if (mockResponseMode === 'truncated_length') {
      return {
        ok: true,
        status: 200,
        json: async () => ({
          id: 'chatcmpl-trunc-1',
          choices: [
            {
              index: 0,
              finish_reason: 'length',
              message: {
                role: 'assistant',
                reasoning_content: '先构思场景连续性与动作承接……',
                content: longNovelParagraphs.slice(0, 180),
              },
            },
          ],
          usage: {
            prompt_tokens: 2800,
            completion_tokens: 1024,
            total_tokens: 3824,
            completion_tokens_details: { reasoning_tokens: 820 },
          },
        }),
      };
    }
    if (mockResponseMode === 'chat_bubbles') {
      return {
        ok: true,
        status: 200,
        json: async () => ({
          id: 'chatcmpl-chat-1',
          choices: [
            {
              index: 0,
              finish_reason: 'stop',
              message: {
                role: 'assistant',
                content: '我刚把摩托车停好。|||你在店里等我两分钟，马上进来。',
              },
            },
          ],
          usage: { prompt_tokens: 950, completion_tokens: 36, total_tokens: 986 },
        }),
      };
    }
    const repeatedLong = longNovelParagraphs + '\n\n' + longNovelParagraphs;
    return {
      ok: true,
      status: 200,
      json: async () => ({
        id: 'chatcmpl-novel-1',
        choices: [
          {
            index: 0,
            finish_reason: 'stop',
            message: {
              role: 'assistant',
              content: repeatedLong,
            },
          },
        ],
        usage: {
          prompt_tokens: 3120,
          completion_tokens: 890,
          total_tokens: 4010,
          completion_tokens_details: { reasoning_tokens: 180 },
        },
      }),
    };
  };

  let { engine } = createPortableEngine({ store: sharedStore, fetchImpl: makeFetch() });

  // Scenario 1 & 2: Import 26-entry Elsewhere preset (24 enabled, 2 disabled)
  const presetPack = load26EntryPresetFixture();
  assert.equal(presetPack.entries.length, 26, 'Fixture has 26 entries');
  assert.equal(presetPack.entries.filter((x: any) => x.enabled).length, 24, '24 entries enabled');
  assert.equal(presetPack.entries.filter((x: any) => !x.enabled).length, 2, '2 entries disabled');

  const importRes = await engine.request('/preset-import', {
    import_mode: 'replace',
    preset: presetPack,
  });
  assert.equal(importRes.ok, true);
  assert.equal(importRes.imported, 26);

  const presetsResp = await engine.request('/presets');
  const meetingEntries = presetsResp.entries.filter((x: any) => x.mode === 'meeting');
  const chatEntries = presetsResp.entries.filter((x: any) => x.mode === 'chat');
  assert.equal(meetingEntries.length, 26, 'All 26 entries imported into meeting mode');
  assert.equal(meetingEntries.filter((x: any) => x.enabled).length, 24, '24 meeting entries enabled');
  assert.equal(meetingEntries.filter((x: any) => !x.enabled).length, 2, '2 meeting entries disabled');
  assert.equal(chatEntries.length, 3, 'Chat presets remain untouched (3 default chat entries)');

  // Check diagnostics on clean replace import
  const meetDiag = presetsResp.diagnostics.meeting;
  assert.equal(meetDiag.totalCount, 26);
  assert.equal(meetDiag.enabledCount, 24);
  assert.equal(meetDiag.disabledCount, 2);
  assert.equal(meetDiag.defaultAndCustomCoexist, false);
  assert.equal(meetDiag.duplicateCount, 0);
  assert.equal(meetDiag.styleGroupTotal, 3);
  assert.equal(meetDiag.enabledStyleCount, 1);
  assert.equal(meetDiag.hasCotCheck, true);
  assert.equal(meetDiag.hasBottomPledge, true);
  assert.equal(meetDiag.rolesBreakdown.system, 23);
  assert.equal(meetDiag.rolesBreakdown.assistant, 1);

  // Scenario 3: Page reload (recreating engine over same localStorage) and mode switch preserve all 26 entries & states
  ({ engine } = createPortableEngine({ store: sharedStore, fetchImpl: makeFetch() }));
  const afterReloadPresets = await engine.request('/presets');
  const reloadedMeeting = afterReloadPresets.entries.filter((x: any) => x.mode === 'meeting');
  assert.equal(reloadedMeeting.length, 26, '26 meeting entries survive page reload');
  assert.equal(reloadedMeeting.filter((x: any) => x.enabled).length, 24, '24 enabled states survive reload');
  assert.equal(reloadedMeeting.filter((x: any) => !x.enabled).length, 2, '2 disabled states survive reload');

  // Configure live API settings with high max_tokens (e.g. 8192)
  const savedSettings = (
    await engine.request('/settings', {
      base_url: 'https://api.example.org/v1',
      api_key: 'sk-live-secret-key-987654321',
      model: 'claude-3-7-sonnet',
      temperature: 0.85,
      top_p: 0.95,
      max_tokens: 8192,
    })
  ).settings;
  assert.equal(savedSettings.mode, 'live');
  assert.equal(savedSettings.max_tokens, 8192, 'Supports max_tokens > 4096 up to 32768');

  // Create two Profiles and match two Characters to test dynamic macro rebinding & all 6 entry points
  const profileA = (
    await engine.request('/profile', {
      name: '奈恩',
      age: 23,
      gender: 'female',
      interested_in: ['all'],
      min_age: 18,
      max_age: 65,
      intent: '认真寻找恋人',
      sources: ['生化危机 · 游戏', '巫师 · 游戏'],
      bio: '喜欢雨天和热可可',
      interests: ['摄影', '黑胶'],
    })
  ).profile;

  const profileB = (
    await engine.request('/profile', {
      name: '陆离',
      age: 25,
      gender: 'female',
      interested_in: ['all'],
      min_age: 18,
      max_age: 65,
      intent: '认识新朋友',
      sources: ['生化危机 · 游戏', '巫师 · 游戏'],
      bio: '喜欢安静的酒馆',
      interests: ['剑术'],
    })
  ).profile;

  const charLeon = 're-game:leon:re2';
  const charChris = 're-game:chris:re5';

  mockResponseMode = 'chat_bubbles';
  for (const [pid, cid] of [
    [profileA.id, charLeon],
    [profileA.id, charChris],
    [profileB.id, charLeon],
  ]) {
    for (let i = 0; i < 15; i++) {
      const sw = await engine.request('/swipe', { profileId: pid, characterId: cid, direction: 'right' });
      if (sw.matched) break;
    }
  }

  // Send a short SMS in chat mode first to verify Scenario 4, 5, and SMS length isolation
  await engine.request('/message', {
    profileId: profileA.id,
    characterId: charLeon,
    text: '我在街角咖啡馆靠窗的位置等你。',
  });
  const chatFlush = await engine.request('/chat-flush', {
    profileId: profileA.id,
    characterId: charLeon,
    force: true,
  });
  assert.equal(chatFlush.reply.mode, 'chat');

  // Scenario 5: Verify chat mode request ONLY used chat presets and NEVER leaked meeting presets
  const lastChatCall = capturedCalls[capturedCalls.length - 1];
  const chatPayloadStr = JSON.stringify(lastChatCall.body.messages);
  assert.ok(chatPayloadStr.includes('只输出角色实际发出的消息正文'), 'Chat mode uses chat-main preset');
  assert.ok(!chatPayloadStr.includes('底部誓约'), 'Chat mode never includes meeting assistant pledge');
  assert.ok(!chatPayloadStr.includes('高饱和度感官电影流'), 'Chat mode never includes meeting style cards');

  // Now switch mock to long_novel for face-to-face meeting tests
  mockResponseMode = 'long_novel';

  // Helper to verify Scenarios 2, 4, 6, 7 on any captured meeting payload
  const assertValidMeetingPayload = (
    messages: Array<{ role: string; content: string }>,
    expectedUserName: string,
    expectedCharName: string
  ) => {
    const fullStr = JSON.stringify(messages);
    // Scenario 4: No chat presets leaked into meeting mode
    assert.ok(
      !fullStr.includes('只输出角色实际发出的消息正文'),
      'Meeting payload must never include chat-main SMS bubble preset'
    );
    // Scenario 2: Disabled entries (毛姆式冷眼世故, 白水烹鲜温润白描) must NEVER enter payload
    assert.ok(!fullStr.includes('毛姆式冷眼世故'), 'Disabled style 1 must not enter payload');
    assert.ok(!fullStr.includes('白水烹鲜温润白描'), 'Disabled style 2 must not enter payload');
    assert.ok(!fullStr.includes('克制冷感的第三方观察者'), 'Disabled style 1 body must not enter payload');
    assert.ok(!fullStr.includes('像温水煮鲜汤'), 'Disabled style 2 body must not enter payload');
    // Enabled style card IS present
    const enabledStyle = meetingEntries.find((x: any) => x.enabled && String(x.group || x.name).includes('文风（单选）'));
    if (enabledStyle) {
      const snippet = enabledStyle.content.slice(0, 18).replace(/\{\{user\}\}/g, expectedUserName).replace(/\{\{char\}\}/g, expectedCharName);
      assert.ok(fullStr.includes(snippet), 'Enabled style card content is present in meeting payload');
    }
    // Scenario 6: Macro replacement ({{user}} and {{char}} completely replaced)
    assert.ok(!fullStr.includes('{{user}}'), '{{user}} macro must be replaced everywhere');
    assert.ok(!fullStr.includes('{{char}}'), '{{char}} macro must be replaced everywhere');
    assert.ok(fullStr.includes(expectedUserName), `Expected user name ${expectedUserName} present`);
    assert.ok(fullStr.includes(expectedCharName), `Expected char name ${expectedCharName} present`);

    // Scenario 7: Structural order check
    // First message is foundational system prompt + core system presets (with expanded {{char}} and {{user}})
    assert.equal(messages[0].role, 'system', 'First message is foundational system message');
    assert.ok(
      messages[0].content.includes(expectedCharName) && messages[0].content.includes(expectedUserName),
      'Core system prompt has expanded {{char}} and {{user}} macros'
    );
    // Last message is ALWAYS role: 'user'
    const lastMsg = messages[messages.length - 1];
    assert.equal(lastMsg.role, 'user', 'Final message in meeting mode must always be role: user');
    // Second-to-last message is the assistant bottom pledge (底部誓约与状态确认)
    const secondLastMsg = messages[messages.length - 2];
    assert.equal(secondLastMsg.role, 'assistant', 'Second-to-last message is assistant bottom pledge');
    assert.ok(
      secondLastMsg.content.includes(expectedUserName) && !secondLastMsg.content.includes('{{user}}'),
      'Assistant bottom pledge has expanded {{user}} macro'
    );
    // Third-to-last message is the post-history system block (COT + Layer 4 Current State)
    const thirdLastMsg = messages[messages.length - 3];
    assert.equal(thirdLastMsg.role, 'system', 'Third-to-last message is post-history COT + Current State system block');
    assert.ok(thirdLastMsg.content.includes('【第四层 · 当前状态'), 'Contains Layer 4 Current State');
  };

  // Scenario 8.1: Entry Point 1 — First time entering meeting mode (/mode with triggerOpening: true)
  const enter1 = await engine.request('/mode', {
    profileId: profileA.id,
    characterId: charLeon,
    mode: 'meeting',
    triggerOpening: true,
    location: '街角咖啡馆',
  });
  assert.equal(enter1.mode, 'meeting');
  assert.ok(enter1.openingReply, 'Generates opening reply');
  assert.ok(enter1.openingReply.text.length >= 800, 'Scenario 10: Long novel reply (800+ chars) is preserved without truncation');
  assertValidMeetingPayload(capturedCalls[capturedCalls.length - 1].body.messages, '奈恩', 'Leon S. Kennedy');
  // Also verify pre-meeting SMS is in system prompt as reference, NOT in dialogue turns
  const openMsgs = capturedCalls[capturedCalls.length - 1].body.messages;
  assert.ok(
    openMsgs[0].content.includes('【见面前的近期手机联系脉络'),
    'Pre-meeting SMS is summarized in system context'
  );
  assert.equal(
    openMsgs.filter((m: any) => m.content === '我在街角咖啡馆靠窗的位置等你。').length,
    0,
    'Short SMS message is not injected as a dialogue turn in meeting mode'
  );

  // Scenario 8.2: Entry Point 2 — User sends a meeting message (/message in meeting mode)
  const meetTurn1 = await engine.request('/message', {
    profileId: profileA.id,
    characterId: charLeon,
    text: '我笑着接过那杯温水，问他最近是不是都没怎么睡好。',
  });
  assert.equal(meetTurn1.mode, 'meeting');
  assert.ok(meetTurn1.reply.text.length >= 800, 'Long novel reply preserved on /message');
  const turn1Msgs = capturedCalls[capturedCalls.length - 1].body.messages;
  assertValidMeetingPayload(turn1Msgs, '奈恩', 'Leon S. Kennedy');
  assert.equal(
    turn1Msgs[turn1Msgs.length - 1].content,
    '我笑着接过那杯温水，问他最近是不是都没怎么睡好。',
    'User latest meeting message sits at the very end after assistant bottom pledge'
  );

  // Scenario 8.3: Entry Point 3 — User clicks Continue (/reply in meeting mode)
  const meetContinue = await engine.request('/reply', {
    profileId: profileA.id,
    characterId: charLeon,
  });
  assert.equal(meetContinue.mode, 'meeting');
  assert.ok(meetContinue.reply.text.length >= 800, 'Long novel reply preserved on /reply continue');
  const contMsgs = capturedCalls[capturedCalls.length - 1].body.messages;
  assertValidMeetingPayload(contMsgs, '奈恩', 'Leon S. Kennedy');
  assert.ok(
    contMsgs[contMsgs.length - 1].content.includes('【继续推进】'),
    'Continue generation ends with explicit user-role continuation trigger'
  );

  // Scenario 8.4: Entry Point 4 — Multi-round meeting generation maintains prior meeting turns in order
  const meetTurn2 = await engine.request('/message', {
    profileId: profileA.id,
    characterId: charLeon,
    text: '我伸手替他理了理微湿的风衣领口。',
  });
  assert.ok(meetTurn2.reply.text.length >= 800);
  const turn2Msgs = capturedCalls[capturedCalls.length - 1].body.messages;
  assertValidMeetingPayload(turn2Msgs, '奈恩', 'Leon S. Kennedy');
  // Prior meeting turns sit between messages[0] and messages[messages.length - 3]
  const middleHistory = turn2Msgs.slice(1, turn2Msgs.length - 3);
  assert.ok(middleHistory.length >= 3, 'Multi-round meeting history is preserved before COT and bottom pledge');

  // Scenario 8.5: Entry Point 5 — End meeting -> return to chat -> start a 2nd meeting later
  await engine.request('/mode', {
    profileId: profileA.id,
    characterId: charLeon,
    mode: 'chat',
    finalizeMeeting: false,
  });
  const enter2 = await engine.request('/mode', {
    profileId: profileA.id,
    characterId: charLeon,
    mode: 'meeting',
    triggerOpening: true,
    location: '老城区唱片行',
  });
  assert.equal(enter2.mode, 'meeting');
  assert.ok(enter2.openingReply.text.length >= 800);
  assertValidMeetingPayload(capturedCalls[capturedCalls.length - 1].body.messages, '奈恩', 'Leon S. Kennedy');

  // Scenario 8.6: Entry Point 6 — Switch to another Character (Chris Redfield) and another Profile (陆离)
  const enterChris = await engine.request('/mode', {
    profileId: profileA.id,
    characterId: charChris,
    mode: 'meeting',
    triggerOpening: true,
    location: '暖炉酒馆',
  });
  assert.equal(enterChris.mode, 'meeting');
  assertValidMeetingPayload(capturedCalls[capturedCalls.length - 1].body.messages, '奈恩', 'Chris Redfield');
  assert.ok(
    !JSON.stringify(capturedCalls[capturedCalls.length - 1].body.messages).includes('Leon S. Kennedy'),
    'Switching character dynamically rebinds {{char}} to Chris Redfield without Leon residue'
  );

  const enterProfileB = await engine.request('/mode', {
    profileId: profileB.id,
    characterId: charLeon,
    mode: 'meeting',
    triggerOpening: true,
    location: '中心靶场',
  });
  assert.equal(enterProfileB.mode, 'meeting');
  assertValidMeetingPayload(capturedCalls[capturedCalls.length - 1].body.messages, '陆离', 'Leon S. Kennedy');
  assert.ok(
    !JSON.stringify(capturedCalls[capturedCalls.length - 1].body.messages).includes('奈恩'),
    'Switching Profile dynamically rebinds {{user}} to 陆离 without 奈恩 residue'
  );

  // Scenario 9: System Log verification (records payload, active presets, sampling, usage, finish_reason, masks API key)
  const logsResp = await engine.request('/system-logs');
  assert.ok(Array.isArray(logsResp.logs) && logsResp.logs.length >= 6, 'System logs recorded for all LLM calls');
  const latestLog = logsResp.logs[0];
  assert.equal(latestLog.mode, 'meeting');
  assert.match(latestLog.entry_point, /^meeting[_-]opening$/);
  assert.equal(latestLog.profile_name, '陆离');
  assert.equal(latestLog.character_name, 'Leon S. Kennedy');
  assert.equal(latestLog.model, 'claude-3-7-sonnet');
  assert.equal(latestLog.sampling.max_tokens, 8192);
  assert.equal(latestLog.active_preset_count, 24);
  assert.equal(latestLog.disabled_preset_count, 2);
  assert.equal(latestLog.active_presets.length, 24);
  assert.equal(latestLog.disabled_presets.length, 2);
  assert.equal(latestLog.finish_reason, 'stop');
  assert.equal(latestLog.usage.prompt_tokens, 3120);
  assert.equal(latestLog.usage.completion_tokens, 890);
  assert.equal(latestLog.usage.reasoning_tokens, 180);
  assert.ok(latestLog.char_count_raw >= 800 && latestLog.char_count_parsed >= 800);
  assert.ok(
    !JSON.stringify(latestLog).includes('sk-live-secret-key-987654321'),
    'Full API key is strictly masked in system logs'
  );
  assert.match(latestLog.headers_masked.Authorization, /^Bearer sk-l.*21$/);

  // Backup export must never include systemLogs or api_key
  const backupJson = JSON.parse(engine.exportData());
  assert.equal(backupJson.data.connection.api_key, '');
  assert.equal('systemLogs' in backupJson.data, false, 'System logs are excluded from backup exports');

  // Scenario 11: Truncation (finish_reason="length") and HTTP Error handling in System Logs
  mockResponseMode = 'truncated_length';
  const truncReply = await engine.request('/message', {
    profileId: profileB.id,
    characterId: charLeon,
    text: '我看着他继续往下说。',
  });
  assert.ok(truncReply.reply.text.length > 0);
  const truncLog = (await engine.request('/system-logs')).logs[0];
  assert.equal(truncLog.finish_reason, 'length');
  assert.ok(truncLog.truncation_warning.includes('max_tokens'), 'Records clear truncation warning on finish_reason=length');
  assert.ok(truncLog.reasoning_content.includes('构思场景连续性'), 'Captures reasoning_content when returned by model');

  mockResponseMode = 'http_error';
  const beforeErrCount = (await engine.request(`/thread?profileId=${profileB.id}&characterId=${charLeon}`)).messages.length;
  const errReply = await engine.request('/message', {
    profileId: profileB.id,
    characterId: charLeon,
    text: '测试接口异常时的降级保护。',
  });
  assert.ok(errReply.warning.includes('HTTP 502'), 'Returns HTTP error warning cleanly');
  const afterErrCount = (await engine.request(`/thread?profileId=${profileB.id}&characterId=${charLeon}`)).messages.length;
  assert.ok(afterErrCount > beforeErrCount, 'Preserves user message and history when API errors');
  const errLog = (await engine.request('/system-logs')).logs[0];
  assert.equal(errLog.http_status, 502);
  assert.ok(errLog.error.includes('HTTP 502'), 'System log records HTTP failure details');

  // Test append conflict diagnostics and user-triggered cleanup actions (disable_defaults & deduplicate)
  await engine.request('/preset', {
    id: 'meeting-main',
    mode: 'meeting',
    name: '线下见面 · 小说模式',
    role: 'system',
    enabled: true,
    content: '默认保底说明',
  });
  await engine.request('/preset-import', {
    import_mode: 'append',
    preset: presetPack,
  });
  const conflictDiag = (await engine.request('/presets')).diagnostics.meeting;
  assert.equal(conflictDiag.defaultAndCustomCoexist, true, 'Detects default + custom preset coexistence after append');
  assert.ok(conflictDiag.duplicateCount >= 26, 'Detects duplicate entries after repeated append');

  await engine.request('/preset', { action: 'disable_defaults', mode: 'meeting' });
  const afterDisableDef = await engine.request('/preset', { action: 'deduplicate', mode: 'meeting' });
  const finalMeetDiag = afterDisableDef.diagnostics.meeting || afterDisableDef.diagnostics;
  assert.equal(finalMeetDiag.defaultAndCustomCoexist, false);
  assert.equal(finalMeetDiag.duplicateCount, 0);
  assert.equal(finalMeetDiag.enabledCount, 24);
});

