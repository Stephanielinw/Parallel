"""End-to-end state invariants for the local HTTP API, using a temporary database."""
import json, tempfile, threading, unittest, urllib.error, urllib.request
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import server

class ParallelAPITest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        server.DATA=Path(cls.tmp.name);server.DBFILE=server.DATA/'test.sqlite3';server.SECRETFILE=server.DATA/'connection.json'
        server.init_db()
        cls.http=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
        cls.port=cls.http.server_address[1]
        cls.thread=threading.Thread(target=cls.http.serve_forever,daemon=True);cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.http.shutdown();cls.http.server_close();cls.thread.join(timeout=2);cls.tmp.cleanup()

    def call(self,path,data=None,status=200):
        req=urllib.request.Request(f'http://127.0.0.1:{self.port}/api{path}',data=json.dumps(data,ensure_ascii=False).encode() if data is not None else None,headers={'Content-Type':'application/json'} if data is not None else {})
        try:
            with urllib.request.urlopen(req,timeout=4) as res:
                self.assertEqual(res.status,status)
                return json.load(res)
        except urllib.error.HTTPError as e:
            self.assertEqual(e.code,status)
            return json.load(e)

    def create(self,name,role='',sources=None):
        return self.call('/profile',{'name':name,'age':26,'gender':'male','interested_in':['all'],'min_age':18,'max_age':65,'intent':'认识新朋友','bio':'喜欢咖啡','interests':['咖啡'],'sources':sources or [],'avatar':'','role_character_id':role,'role_hint':''})['profile']

    def test_01_identity_and_parallel_version(self):
        self.assertEqual(self.call('/health')['ok'],True)
        self.assertGreaterEqual(len(self.call('/identify?name=Leon')['matches']),3)
        leon=self.create('Leon',role='re-game:leon:re2')
        self.__class__.leon=leon
        ids={x['id'] for x in self.call('/candidates?profileId='+leon['id'])['candidates']}
        # Random ten drawn from whole catalog may not contain the alternate; test the entire eligibility set directly.
        with server.connect() as db:
            pool={x['id'] for x in server.possible_candidates(db,server.profile_get(db,leon['id']))}
        self.assertNotIn('re-game:leon:re2',pool)
        self.assertIn('re-game:leon:re4',pool)
        self.assertIn('re-game:leon:re6',pool)
        forbidden=self.call('/swipe',{'profileId':leon['id'],'characterId':'re-game:leon:re2','direction':'right'},400)
        self.assertIn('自己',forbidden['error'])
        film=self.create('Film Fan',sources=['生化危机 · 电影'])
        batch=self.call('/discover',{'profileId':film['id']})
        self.assertEqual(batch['generation'],'catalog-demo')
        self.assertEqual(len(batch['candidates']),10)
        self.assertEqual(len({c['id'] for c in batch['candidates']}),10)
        self.assertTrue(all(c['source']=='生化危机 · 电影' for c in batch['candidates']))
        custom=self.create('Custom Tag',sources=['生化危机'])
        self.assertEqual(custom['sources'],['生化危机'])
        with server.connect() as db:
            pool=server.possible_candidates(db,server.profile_get(db,custom['id']))
        self.assertTrue(any(c['source']=='生化危机 · 游戏' for c in pool))
        self.assertTrue(any(c['source']=='生化危机 · 电影' for c in pool))
        unknown=self.create('Unknown Work',sources=['完全未收录的小说'])
        self.assertEqual(unknown['sources'],['完全未收录的小说'])
        self.assertEqual(self.call('/discover',{'profileId':unknown['id']})['candidates'],[])

    def test_02_profiles_match_and_reunite(self):
        steph=self.create('Stephanie')
        self.__class__.steph=steph
        cid='re-game:leon:re2';matched=False
        for _ in range(12):
            r=self.call('/swipe',{'profileId':steph['id'],'characterId':cid,'direction':'right'})
            if r['matched']:matched=True;break
        self.assertTrue(matched)
        first=self.call('/thread?profileId='+steph['id']+'&characterId='+cid)
        self.assertTrue(first['messages'][0]['engine']=='demo')
        r=self.call('/message',{'profileId':steph['id'],'characterId':cid,'text':'我喜欢电影'})
        self.assertEqual(r['mode'],'chat')
        before=len(self.call('/thread?profileId='+steph['id']+'&characterId='+cid)['messages'])
        self.call('/unmatch',{'profileId':steph['id'],'characterId':cid})
        self.assertFalse(self.call('/threads?profileId='+steph['id'])['threads'])
        for _ in range(12):
            r=self.call('/swipe',{'profileId':steph['id'],'characterId':cid,'direction':'right'})
            if r['matched']:break
        self.assertTrue(r['matched'])
        after=self.call('/thread?profileId='+steph['id']+'&characterId='+cid)
        self.assertGreater(len(after['messages']),before)
        self.assertIn('又见面',after['messages'][-1]['text'])
        self.assertTrue(any(m['text']=='我喜欢电影' for m in after['messages']))

    def test_03_meeting_and_cross_profile_persona(self):
        pid=self.__class__.steph['id'];cid='re-game:leon:re2'
        r=self.call('/message',{'profileId':pid,'characterId':cid,'text':'我到了，在咖啡店门口'})
        self.assertTrue(r['queued']);self.assertIsNone(r['reply']);self.assertEqual(r['mode'],'chat')
        self.call('/mode',{'profileId':pid,'characterId':cid,'mode':'meeting'})
        next_reply=self.call('/reply',{'profileId':pid,'characterId':cid})
        self.assertEqual(next_reply['reply']['mode'],'meeting')
        self.assertEqual(next_reply['mode'],'meeting')
        prior=self.call('/thread?profileId='+pid+'&characterId='+cid)['messages']
        self.assertTrue(any(x['mode']=='chat' for x in prior))
        self.assertTrue(any(x['mode']=='meeting' for x in prior))
        self.call('/mode',{'profileId':pid,'characterId':cid,'mode':'chat'})
        # The user-controlled Leon and the AI Leon are NEVER the same entity.
        with server.connect() as db:
            p=server.profile_get(db,self.__class__.leon['id']);self.assertEqual(p['role_character_id'],cid)
            current,others=server.latest_memory(db,cid,self.__class__.leon['id'])
            self.assertEqual(current,[])
            self.assertTrue(any(x['person']=='Stephanie' for x in others))
            self.assertTrue(any(x['type']=='meeting' for x in others))

    def test_03a_60_second_quiet_batch_and_text_photo(self):
        pid=self.__class__.steph['id'];cid='re-game:leon:re2'
        one=self.call('/message',{'profileId':pid,'characterId':cid,'text':'第一条'})
        two=self.call('/message',{'profileId':pid,'characterId':cid,'text':'第二条'})
        self.assertTrue(one['queued'])
        self.assertGreaterEqual(two['queue']['count'],2)
        self.assertIsNone(one['reply'])
        still=self.call('/chat-flush',{'profileId':pid,'characterId':cid})
        self.assertIsNone(still['reply'])
        self.assertTrue(still['queued'])
        with server.connect() as db:
            db.execute('UPDATE chat_queue SET due_at=? WHERE profile_id=? AND character_id=?',(server.now_ms()-1,pid,cid))
            db.commit()
        done=self.call('/chat-flush',{'profileId':pid,'characterId':cid})
        self.assertIsNotNone(done['reply'])
        self.assertEqual(done['queue']['count'],0)
        duplicate=self.call('/chat-flush',{'profileId':pid,'characterId':cid,'force':True})
        self.assertIsNone(duplicate['reply'])
        new=self.call('/message',{'profileId':pid,'characterId':cid,'text':'准备见面了'})
        self.assertEqual(new['queue']['count'],1)
        self.call('/mode',{'profileId':pid,'characterId':cid,'mode':'meeting'})
        thread=self.call('/thread?profileId='+pid+'&characterId='+cid)
        self.assertEqual(thread['queue']['count'],0)
        self.assertTrue(any(m['text']=='准备见面了' for m in thread['messages']))
        old_len=len(thread['messages'])
        self.call('/mode',{'profileId':pid,'characterId':cid,'mode':'chat'})
        self.assertIsNone(self.call('/chat-flush',{'profileId':pid,'characterId':cid,'force':True})['reply'])
        self.assertEqual(len(self.call('/thread?profileId='+pid+'&characterId='+cid)['messages']),old_len)
        photo=self.call('/photo-description',{'characterId':cid})
        self.assertIn('Leon',photo['description'])
        self.assertNotIn('portrait',photo)

    def test_04_terminal_and_presets(self):
        x=self.call('/settings',{'base_url':'https://example.org/v1','api_key':'test-secret-abc','model':'test-model','temperature':1.15,'top_p':.7,'image_model':'image-test'})['settings']
        self.assertTrue(x['has_key']);self.assertNotIn('api_key',x)
        self.assertNotIn('test-secret-abc',json.dumps(self.call('/settings')))
        bad=self.call('/settings',{'base_url':'http://example.com/v1'},400)
        self.assertIn('HTTPS',bad['error'])
        presets=self.call('/presets')['entries']
        self.assertGreaterEqual(len(presets),5)
        created=self.call('/preset',{'mode':'meeting','name':'节奏控制','content':'不要过快推进','role':'system','enabled':True})
        self.assertIn(created['id'],[p['id'] for p in self.call('/presets')['entries']])
        self.call('/settings',{'clear_key':True})

    def test_05_own_preset_import_export_roundtrip(self):
        original=self.call('/presets')['entries']
        chat=[x for x in original if x['mode']=='chat']
        meeting=[x for x in original if x['mode']=='meeting']
        pack={'format':'parallel-text-preset','schemaVersion':1,'modes':['chat'],
              'name':'本地试验','entries':[{'mode':'chat','name':'独立预设','role':'system',
                'enabled':False,'content':'随时遵循当前聊天角色的设定','sort_order':0}]}
        fail=self.call('/preset-import',{'import_mode':'append','preset':{'format':'third-party-preset','schemaVersion':1,'modes':['chat'],'entries':pack['entries']}},400)
        self.assertIn('Parallel',fail['error'])
        self.assertEqual(self.call('/presets')['entries'],original)
        r=self.call('/preset-import',{'import_mode':'append','preset':pack})
        self.assertEqual(r['imported'],1)
        after=self.call('/presets')['entries']
        self.assertEqual(len(after),len(original)+1)
        self.assertEqual(len([x for x in after if x['mode']=='meeting']),len(meeting))
        self.assertEqual(next(x for x in after if x['name']=='独立预设')['enabled'],False)
        invalid={**pack,'entries':[{**pack['entries'][0],'content':12}]}
        self.assertIn('条目',self.call('/preset-import',{'import_mode':'replace','preset':invalid},400)['error'])
        self.assertEqual(self.call('/presets')['entries'],after)
        self.call('/preset-import',{'import_mode':'replace','preset':pack})
        final=self.call('/presets')['entries']
        self.assertEqual(len([x for x in final if x['mode']=='chat']),1)
        self.assertEqual(len([x for x in final if x['mode']=='meeting']),len(meeting))
        self.assertFalse(next(x for x in final if x['mode']=='chat')['enabled'])
        self.assertEqual(next(x for x in final if x['mode']=='chat')['content'],pack['entries'][0]['content'])

    def test_06_elsewhere_owned_meeting_preset(self):
        pack={'format':'elsewhere-preset','schemaVersion':1,'id':'test-owned','name':'小狗乐园测试版','entries':[
            {'id':'a','name':'人物规则','role':'system','enabled':True,'group':'入园仪式','content':'你是 {{char}}，对方是 {{user}}。'},
            {'id':'b','name':'文风备选','role':'system','enabled':False,'group':'文风','content':'只在启用后生效'},
            {'id':'c','name':'确认','role':'assistant','enabled':True,'group':'收尾','content':'我记得 {{char}} 与 {{user}}。'}]}
        untouched=json.dumps(pack,ensure_ascii=False)
        before=self.call('/presets')['entries']
        reply=self.call('/preset-import',{'import_mode':'replace','preset':pack})
        self.assertEqual(reply['imported'],3)
        items=self.call('/presets')['entries']
        self.assertEqual([x['role'] for x in items if x['mode']=='meeting'],['system','system','assistant'])
        self.assertEqual([x['enabled'] for x in items if x['mode']=='meeting'],[True,False,True])
        self.assertEqual(len([x for x in items if x['mode']=='chat']),len([x for x in before if x['mode']=='chat']))
        self.assertEqual(json.dumps(pack,ensure_ascii=False),untouched)
        with server.connect() as db:
            p=server.profile_get(db,self.__class__.steph['id'])
            msgs=server.compile_messages(db,p,server.BY_ID['re-game:leon:re2'],'meeting')
        rendered=json.dumps(msgs,ensure_ascii=False)
        self.assertIn('Leon S. Kennedy',rendered)
        self.assertIn('Stephanie',rendered)
        self.assertNotIn('{{char}}',rendered)
        self.assertNotIn('{{user}}',rendered)
        self.assertNotIn('只在启用后生效',rendered)
        self.assertTrue(any(x['role']=='assistant' and '我记得' in x['content'] for x in msgs))
        bad=dict(pack,entries=[dict(pack['entries'][0],id='a'),dict(pack['entries'][0],id='a')])
        self.call('/preset-import',{'import_mode':'replace','preset':bad},400)
        self.assertEqual(len(self.call('/presets')['entries']),len(items))

if __name__=='__main__':unittest.main()
