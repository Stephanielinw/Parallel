const fs=require('fs'); const vm=require('vm'); const assert=require('assert');
const src=fs.readFileSync(require('path').join(__dirname,'../static/offline.js'),'utf8');
const map=new Map();
const localStorage={getItem:k=>map.get(k)||null,setItem:(k,v)=>map.set(k,v)};
function start(){const win={};const context={window:win,localStorage,crypto:require('crypto').webcrypto,URLSearchParams,Date,JSON,Math,TextEncoder,console,fetch:async()=>{throw Error('network disabled in tests')}};vm.createContext(context);vm.runInContext(src,context);return win.ParallelOffline}
(async()=>{
 let app=start(); let p=(await app.request('/profile',{name:'Stephanie',age:26,gender:'female',interested_in:['all'],min_age:18,max_age:65,intent:'认识朋友',sources:['生化危机 · 游戏'],bio:'你好',interests:[],avatar:'',role_character_id:''})).profile;
 let me=(await app.request('/profile',{name:'Leon',age:21,gender:'male',interested_in:['all'],min_age:18,max_age:65,intent:'寻找缘分',sources:['生化危机 · 游戏'],bio:'',interests:[],avatar:'',role_character_id:'re-game:leon:re2'})).profile;
 let candidates=(await app.request('/discover',{profileId:me.id})).candidates;
 assert(!candidates.some(x=>x.id==='re-game:leon:re2'),'player Leon cannot match AI same-era Leon');
 const list=await app.request('/identify?name=Leon');assert(list.matches.length>2,'multiple canonical versions can resolve');
 const cid='re-game:leon:re2';const uriGuard=()=>`/thread?profileId=${p.id}&characterId=${cid}`;let match=null;
 for(let i=0;i<15;i++){match=await app.request('/swipe',{profileId:p.id,characterId:cid,direction:'right'});if(match.matched)break}
 let tagged=(await app.request('/profile',{name:'Custom',age:25,gender:'female',interested_in:['all'],min_age:18,max_age:60,sources:['生化危机','完全未收录的小说'],bio:'',interests:[],avatar:'',role_character_id:''})).profile;
 assert.deepStrictEqual([...tagged.sources],['生化危机','完全未收录的小说']);
 const tagCandidates=(await app.request('/discover',{profileId:tagged.id})).candidates;
 assert(tagCandidates.every(c=>c.source.includes('生化危机')));
 assert(match.matched,'match eventually succeeds');
 let firstQueue=await app.request('/message',{profileId:p.id,characterId:cid,text:'我们明天见'});
 assert(firstQueue.queued&&firstQueue.reply===null,'chat text queued without immediate reply');
 let secondQueue=await app.request('/message',{profileId:p.id,characterId:cid,text:'等一下，我还有一句'});
 assert(secondQueue.queue.count===2,'two SMS share quiet queue');
 let beforeDue=await app.request('/chat-flush',{profileId:p.id,characterId:cid});
 assert(beforeDue.queued&&beforeDue.reply===null,'no response before 60s');
 let batched=await app.request('/chat-flush',{profileId:p.id,characterId:cid,force:true});
 assert(batched.reply&&batched.queue.count===0,'manual flush returns one batched AI reply');
 let dup=await app.request('/chat-flush',{profileId:p.id,characterId:cid,force:true});assert(!dup.reply,'no duplicate flush');
 let switchQueue=await app.request('/message',{profileId:p.id,characterId:cid,text:'先发完再见面'});
 assert(switchQueue.queue.count===1);
 
 await app.request('/mode',{profileId:p.id,characterId:cid,mode:'meeting'});
 assert((await app.request(uriGuard())).queue.count===0,'switching to meeting cancels pending chat reply');
 let r=await app.request('/reply',{profileId:p.id,characterId:cid});assert(r.reply.mode==='meeting','reply should use the mode switched after the last text');
 await app.request('/mode',{profileId:p.id,characterId:cid,mode:'chat'});
 await app.request('/reply',{profileId:p.id,characterId:cid});
 const uri=`/thread?profileId=${p.id}&characterId=${cid}`;
 let msgs=(await app.request(uri)).messages;
 assert(msgs.some(x=>x.mode==='meeting')&&msgs.some(x=>x.mode==='chat'));
 await app.request('/unmatch',{profileId:p.id,characterId:cid});
 let earlier=msgs.length;
 for(let i=0;i<15;i++){match=await app.request('/swipe',{profileId:p.id,characterId:cid,direction:'right'});if(match.matched)break}
 assert(match.matched);
 assert((await app.request(uri)).messages.length>earlier);
 const initPresets=(await app.request('/presets')).entries;
 const ownPreset={format:'parallel-text-preset',schemaVersion:1,modes:['chat'],name:'测试',entries:[{mode:'chat',name:'角色一致性',role:'system',enabled:false,content:'保持角色本人的说话方式',sort_order:0}]};
 let rejected=false;
 try{await app.request('/preset-import',{import_mode:'replace',preset:{...ownPreset,format:'sillytavern'}})}catch(e){rejected=true}
 assert(rejected,'no third-party preset import');
 await app.request('/preset-import',{import_mode:'append',preset:ownPreset});
 let entries=(await app.request('/presets')).entries;
 assert.equal(entries.length,initPresets.length+1);
 assert(entries.find(x=>x.name==='角色一致性').enabled===false);
 await app.request('/preset-import',{import_mode:'replace',preset:ownPreset});
 entries=(await app.request('/presets')).entries;
 assert.equal(entries.filter(x=>x.mode==='chat').length,1);
 assert.equal(entries.filter(x=>x.mode==='meeting').length,initPresets.filter(x=>x.mode==='meeting').length);
 assert.equal(entries.find(x=>x.name==='角色一致性').content,ownPreset.entries[0].content);
 const photo=await app.request('/photo-description',{characterId:cid});assert(photo.description.includes('Leon'),'photo is described textually');
 const ownElsewhere={format:'elsewhere-preset',schemaVersion:1,entries:[
   {id:'one',name:'角色一致性',group:'基础',role:'system',enabled:true,content:'{{char}} 知道 {{user}} 的名字'},
   {id:'two',name:'隐藏条目',group:'文风',role:'system',enabled:false,content:'禁用'},
   {id:'three',name:'确认',group:'收尾',role:'assistant',enabled:true,content:'我会遵守角色规则'}]};
 const res=await app.request('/preset-import',{import_mode:'replace',preset:ownElsewhere});assert(res.imported===3);
 let imported=(await app.request('/presets')).entries.filter(x=>x.mode==='meeting').sort((a,b)=>a.sort_order-b.sort_order);
 assert(imported.length===3&&imported[2].role==='assistant'&&!imported[1].enabled,'Elsewhere owned JSON imported to meeting only');
  const backup=JSON.parse(app.exportData());assert(!backup.data.connection.api_key);
 app=start();assert((await app.request(uri)).messages.length>earlier,'localStorage persistence across refresh');
 const restored=app.importData(JSON.stringify(backup));assert(restored.profiles===3,'data restore');
 console.log('Portable HTML data tests passed: profile role exclusion, timeline, mode, reply, reunion, persistence, backup');
})().catch(e=>{console.error(e);process.exit(1)});
